import UIKit


var items: [String] = ["Bikes", "Brooch", "Incense", "Jewelry", "Lip Gloss", "Phone Cases", "Rings", "Rocks", "Shoes"]
items += ["Video Game Skins"]

if items.isEmpty {
    print("Item Collection is Empty")
} else {
    print ("It is Items in your Collection")
}



print("My collection has \(items.count) items.")




for item in items {
    print(item)
}




